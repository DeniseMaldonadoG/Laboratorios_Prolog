suma(A, B, Resultado) :-
    Resultado is A + B.

restar(A, B, Resultado) :-
    Resultado is A - B.