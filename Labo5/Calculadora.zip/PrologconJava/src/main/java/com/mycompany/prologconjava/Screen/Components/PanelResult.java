/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prologconjava.Screen.Components;


import com.mycompany.prologconjava.Screen.Theme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;

public class PanelResult extends JPanel {  

    private final JLabel lblTitulo = new JLabel("Resultado");  
    private final JTextArea txtResultado = new JTextArea(1, 20);  

    public PanelResult() {  
        super(new BorderLayout(0, 6));  
        setOpaque(false);  

        lblTitulo.setFont(Theme.sans(Font.BOLD, 12));  
        lblTitulo.setForeground(Theme.MUTED);  

        txtResultado.setEditable(false);  
        txtResultado.setLineWrap(true);  
        txtResultado.setWrapStyleWord(true);  
        txtResultado.setFont(Theme.mono(Font.PLAIN, 17));  
        txtResultado.setBackground(Theme.CARD);  
        txtResultado.setForeground(Theme.TEXT);  
        txtResultado.setCaretColor(Theme.CARD);  
        txtResultado.setBorder(new EmptyBorder(8, 12, 8, 12));  

        JScrollPane scroll = new JScrollPane(txtResultado);  
        scroll.setBorder(new LineBorder(Theme.BORDER, 1, true));  
        scroll.getViewport().setBackground(Theme.CARD);  
        
        // Desactivar barras de scroll
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(lblTitulo, BorderLayout.NORTH);  
        add(scroll, BorderLayout.CENTER);  
    }  

    public void setTitulo(String titulo) {  
        lblTitulo.setText(titulo);  
    }  

    public void setTexto(String texto) {  
        txtResultado.setText(texto);  
    }  

    public String getTexto() {  
        return txtResultado.getText();  
    }  
}