/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prologconjava.Screen;


import com.mycompany.prologconjava.Connection;
import com.mycompany.prologconjava.Screen.Components.Buttons;
import com.mycompany.prologconjava.Screen.Components.PanelResult;
import com.mycompany.prologconjava.Screen.Components.TextField;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.datatransfer.StringSelection;

public class Window extends JFrame {  

    private final TextField txtA = new TextField("Ej: 10");  
    private final TextField txtB = new TextField("Ej: 23");  
    
    private final PanelResult panelSuma = new PanelResult();  
    private final PanelResult panelResta = new PanelResult();  
    
    private final JLabel lblEstado = new JLabel(" ");  

    public Window(Connection motor) {  
        super("Calculadora de Suma y Resta en Prolog");  

        panelSuma.setTitulo("Resultado de la Suma");
        panelResta.setTitulo("Resultado de la Resta");

        JPanel contenido = new JPanel();  
        contenido.setLayout(new BoxLayout(contenido, BoxLayout.Y_AXIS));  
        contenido.setOpaque(false);  

        // Panel para organizar los dos inputs
        JPanel panelInputs = new JPanel(new GridLayout(1, 2, 10, 0));
        panelInputs.setOpaque(false);
        panelInputs.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        
        JPanel p1 = new JPanel(new BorderLayout(0, 4));
        p1.setOpaque(false);
        p1.add(etiqueta("Numero A"), BorderLayout.NORTH);
        p1.add(txtA, BorderLayout.CENTER);

        JPanel p2 = new JPanel(new BorderLayout(0, 4));
        p2.setOpaque(false);
        p2.add(etiqueta("Numero B"), BorderLayout.NORTH);
        p2.add(txtB, BorderLayout.CENTER);

        panelInputs.add(p1);
        panelInputs.add(p2);

        JPanel panelResultadosDoble = new JPanel(new GridLayout(1, 2, 10, 0));
        panelResultadosDoble.setOpaque(false);
        panelResultadosDoble.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
        panelResultadosDoble.add(panelSuma);
        panelResultadosDoble.add(panelResta);

        agregar(contenido, panelInputs, 14);  
        agregar(contenido, crearBotones(motor), 18);  
        agregar(contenido, panelResultadosDoble, 14);  
        agregar(contenido, crearPie(), 0);  

        JPanel raiz = new JPanel(new BorderLayout(0, 20));  
        raiz.setBackground(Theme.BG);  
        raiz.setBorder(new EmptyBorder(24, 28, 24, 28));  
        raiz.add(crearEncabezado(), BorderLayout.NORTH);  
        raiz.add(contenido, BorderLayout.CENTER);  

        setContentPane(raiz);  
        setMinimumSize(new Dimension(660, 440));  
        pack();  
        setDefaultCloseOperation(EXIT_ON_CLOSE);  
        setLocationRelativeTo(null);  
    }  

    private JPanel crearEncabezado() {  
        JLabel titulo = new JLabel("Cálculo Simbólico");  
        titulo.setFont(Theme.sans(Font.BOLD, 24));  
        titulo.setForeground(Theme.TEXT);  

        JLabel subtitulo = new JLabel("Calcula suma y resta");  
        subtitulo.setFont(Theme.sans(Font.PLAIN, 13));  
        subtitulo.setForeground(Theme.MUTED);  

        JPanel p = new JPanel();  
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));  
        p.setOpaque(false);  
        p.add(titulo);  
        p.add(Box.createVerticalStrut(4));  
        p.add(subtitulo);  
        return p;  
    }  

    private JPanel crearBotones(Connection motor) {  
        Buttons btnSumar = new Buttons("Sumar", Theme.BLUE, Theme.BG, 26, 11, 14);  
        Buttons btnRestar = new Buttons("Restar", Theme.GREEN, Theme.BG, 26, 11, 14);  

        btnSumar.addActionListener(e -> ejecutar(motor, "suma", panelSuma));  
        btnRestar.addActionListener(e -> ejecutar(motor, "restar", panelResta));  

        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));  
        p.setOpaque(false);  
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        p.add(btnSumar);  
        p.add(btnRestar);  
        return p;  
    }  

    private JPanel crearPie() {  
        lblEstado.setFont(Theme.sans(Font.PLAIN, 12));  
        lblEstado.setForeground(Theme.MUTED);  

        Buttons btnCopiar = new Buttons("Copiar resultado", Theme.CARD, Theme.TEXT, 16, 7, 12);  
        btnCopiar.addActionListener(e -> copiarResultado(panelSuma));  

        
        JPanel panelBoton = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        panelBoton.setOpaque(false);
        panelBoton.add(btnCopiar);

        JPanel p = new JPanel(new BorderLayout());  
        p.setOpaque(false);  
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 35));
        p.add(lblEstado, BorderLayout.WEST);  
        p.add(panelBoton, BorderLayout.EAST);  
        return p;  
    }  

    private void ejecutar(Connection motor, String pred, PanelResult panelDestino) {  
        String valA = txtA.getText().trim();  
        String valB = txtB.getText().trim();  

        if (valA.isEmpty() || valB.isEmpty()) {  
            lblEstado.setText("Escribe ambos numeros primero.");
            lblEstado.setForeground(Theme.AMBER);
            return;  
        }  

        try {  
            String query = valA + ", " + valB;
            String resultado = motor.consultar(pred, query);  
            
            if (resultado.startsWith("Sin solución")) {  
                panelDestino.setTexto("");
                lblEstado.setText(resultado);  
                lblEstado.setForeground(Theme.AMBER);  
            } else {  
                panelDestino.setTexto(resultado);  
                lblEstado.setText("Listo (" + pred + ")");  
                lblEstado.setForeground(Theme.GREEN);  
            }  
        } catch (Exception ex) {  
            lblEstado.setText("Valores invalidos: " + ex.getMessage());  
            lblEstado.setForeground(Theme.RED);  
        }  
    }  

    private void copiarResultado(PanelResult panel) {  
        String t = panel.getTexto();  
        if (t.isEmpty()) {  
            return;  
        }  
        Toolkit.getDefaultToolkit().getSystemClipboard()  
                .setContents(new StringSelection(t), null);  
        lblEstado.setText("Copiado al portapapeles");  
        lblEstado.setForeground(Theme.BLUE);  
    }  

    private static void agregar(JPanel panel, JComponent c, int espacioDespues) {  
        c.setAlignmentX(Component.LEFT_ALIGNMENT);  
        panel.add(c);  
        if (espacioDespues > 0) {  
            panel.add(Box.createVerticalStrut(espacioDespues));  
        }  
    }  

    private static JLabel etiqueta(String texto) {  
        JLabel l = new JLabel(texto);  
        l.setFont(Theme.sans(Font.BOLD, 12));  
        l.setForeground(Theme.MUTED);  
        return l;  
    }  
}