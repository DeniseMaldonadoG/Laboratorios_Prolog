/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prologconjava;

import alice.tuprolog.Prolog;
import alice.tuprolog.SolveInfo;
import alice.tuprolog.Theory;
import java.io.InputStream;

/**
 *
 * @author denis
 */

public class Connection {
    
 
private final Prolog engine = new Prolog();  
public Connection() throws Exception {  
try (InputStream in = getClass().getResourceAsStream("/calculo.pl")) 
{  
if (in == null) throw new IllegalStateException("No se encontró calculo.pl");  
engine.setTheory(new Theory(in));  
}  
}  
public String consultar(String predicado, String expresion) throws Exception {  
    // Arma la consulta exacta como: suma(8, 2, R). o restar(8, 2, R).
    SolveInfo info = engine.solve(predicado + "(" + expresion + ", R).");  
    return info.isSuccess() ? info.getTerm("R").toString()  
            : "Sin solución para esa expresión";  
} }