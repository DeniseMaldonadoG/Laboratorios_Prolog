/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prologconjava;


import com.mycompany.prologconjava.Screen.Window;
import javax.swing.SwingUtilities;

/**
 *
 * @author denis
 */


public class Main {
public static void main(String[] args) throws Exception {
Connection motor = new Connection();
SwingUtilities.invokeLater(() -> new Window(motor).setVisible(true));
}
}